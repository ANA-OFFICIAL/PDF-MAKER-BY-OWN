const { jsPDF } = window.jspdf;

document.getElementById("imageInput").addEventListener("change", previewImages);
document.getElementById("generatePdf").addEventListener("click", generatePDF);

let imageFiles = [];

function previewImages(event) {
  const files = event.target.files;
  const previewContainer = document.getElementById("preview");
  previewContainer.innerHTML = ""; // Clear previous previews

  imageFiles = Array.from(files); // Store selected images

  imageFiles.forEach(file => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = document.createElement("img");
      img.src = reader.result;
      previewContainer.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
}

function generatePDF() {
  if (imageFiles.length === 0) {
    alert("Please upload at least one image.");
    return;
  }

  const pdf = new jsPDF();
  let width = pdf.internal.pageSize.getWidth();
  let height = pdf.internal.pageSize.getHeight();

  imageFiles.forEach((file, index) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.src = reader.result;

      img.onload = () => {
        const imgWidth = img.width;
        const imgHeight = img.height;
        const ratio = Math.min(width / imgWidth, height / imgHeight);

        const imgX = (width - imgWidth * ratio) / 2;
        const imgY = (height - imgHeight * ratio) / 2;

        if (index > 0) pdf.addPage();
        pdf.addImage(img, "JPEG", imgX, imgY, imgWidth * ratio, imgHeight * ratio);

        if (index === imageFiles.length - 1) pdf.save("images.pdf");
      };
    };
    reader.readAsDataURL(file);
  });
}
